from qiskit import QuantumCircuit

qc = QuantumCircuit(2)
qc.h(0)
qc.h(1)
