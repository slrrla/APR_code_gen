from qiskit import QuantumCircuit, transpile

lam = 0.5

qc = QuantumCircuit(1)
# FIX: u1 cannot be unrolled into the requested basis while preserving its phase -> use Rz with the equivalent global phase, because U1(lam) = exp(i*lam/2) Rz(lam)
qc.rz(lam, 0)
qc.global_phase = lam / 2

transpiled = transpile(qc, basis_gates=['rx', 'ry', 'rz'])
print(transpiled)
