from qiskit import *

simulator = Aer.get_backend('qasm_simulator')
qr = QuantumRegister(1)
cr = ClassicalRegister(1)
circuit = QuantumCircuit(qr, cr)
circuit.h(qr[0])
circuit.measure(qr, cr)

job = execute(circuit, backend=simulator, shots=1024)
# FIX: passed the job to result and printed the full result -> retrieve measurement counts, because get_counts() returns the measured 0/1 data
a = job.result().get_counts()
print(a)

