import qiskit
from qiskit import QuantumCircuit, QuantumRegister

qr = QuantumRegister(2, 'q')
qc = QuantumCircuit(qr)
qc.h(0)
qc.cx(0, 1)

for instruction, qargs, cargs in qc.data:
    qbit: qiskit.circuit.Qubit = qargs[0]
    # FIX: deprecated back-reference to the containing register -> use the circuit's bit location, because Bit.register is deprecated
    print(qc.find_bit(qbit).registers[0][0])
    # FIX: deprecated back-reference to the bit's register index -> use the register location, because Bit.index is deprecated
    print(qc.find_bit(qbit).registers[0][1])
